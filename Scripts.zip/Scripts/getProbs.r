commandLineArgs = commandArgs(trailingOnly = TRUE)

if (length(commandLineArgs) != 1)
{
	cat("\n\tWrong parameters.\n\n\tRequired parameters:\n\n\t\t\tMaps file\n\n")
	quit(save = "no", status = 64, runLast = FALSE)
}

#Parse command line arguments
mapsFile = commandLineArgs[1]

library(phytools)

#Read the simmap from file
sm = read.simmap(file = mapsFile, format = "phylip")

#Summarise the simmap
summ = summary(sm)

#Print the probabilities for the interesting nodes
cat("Probs:\n")
print(summ$ace[1,])
print(summ$ace[53,])
print(summ$ace[54,])
