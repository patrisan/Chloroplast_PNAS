commandLineArgs = commandArgs(trailingOnly = TRUE)

if (length(commandLineArgs) != 3)
{
	cat("\n\tWrong parameters.\n\n\tRequired parameters:\n\n\t\t\tTree file\tData file\t\tSeed\n\n")
	quit(save = "no", status = 64, runLast = FALSE)
}

#Parse command line arguments
sptreeFile = commandLineArgs[1]
dataFile = commandLineArgs[2]
seed = commandLineArgs[3]

library(corHMM)
library(phytools)

set.seed(seed)

#Read the species tree file
tree = read.tree(sptreeFile)
tree$tip.label = tolower(tree$tip.label)
tree = ladderize(tree, right=FALSE)

#Read character state data
parsed_data = read.table(dataFile, header=FALSE, sep="\t")

#Create data frames
multiState = data.frame(Names=parsed_data$V1, Habitat=parsed_data$V2, stringsAsFactors=FALSE)
binary = data.frame(Names=parsed_data$V1, Habitat=parsed_data$V3, stringsAsFactors=FALSE)

#Multistate
	#Run simulation
	unordERMul = rayDISC(phy = tree, data = multiState, model = "ER", node.states = "marginal", root.p = "maddfitz")
	unordARDMul = rayDISC(phy = tree, data = multiState, model = "ARD", node.states = "marginal", root.p = "maddfitz")
	unordSYMMul = rayDISC(phy = tree, data = multiState, model = "SYM", node.states = "marginal", root.p = "maddfitz")


	#Create rate matrices for ordered models
	ordER = rate.mat.maker(rate.cat=1, hrm=FALSE, ntraits=1, nstates=3, model="ER")
	ordER[1, 2] = NA
	ordER[2, 1] = NA
	ordARD = rate.mat.maker(rate.cat=1, hrm=FALSE, ntraits=1, nstates=3, model="ARD")
	ordARD = rate.par.drop(ordARD, drop.par = c(1,3))
	ordSYM = rate.mat.maker(rate.cat=1, hrm=FALSE, ntraits=1, nstates=3, model="SYM")
	ordSYM = rate.par.drop(ordSYM, drop.par = 1)
	
	#Run simulation
	ordERMul = rayDISC(phy=tree, data=multiState, model="ER", rate.mat=ordER, node.states="marginal", root.p="maddfitz")
	ordARDMul = rayDISC(phy=tree, data=multiState, model="ARD", rate.mat = ordARD, node.states = "marginal", root.p = "maddfitz")
	ordSYMMul = rayDISC(phy=tree, data=multiState, model="SYM", rate.mat = ordSYM, node.states = "marginal", root.p = "maddfitz")
	
	#Create rate matrices for "Some Rates Different" models
	SRD1 = rate.mat.maker(rate.cat=1, hrm=FALSE, ntraits=1, nstates=3, model="ARD")
	SRD1[1,2] = 1
	SRD2 = rate.mat.maker(rate.cat=1, hrm=FALSE, ntraits=1, nstates=3, model="ARD")
	SRD2[1,2] = 1
	SRD2[3,2] = 2
	SRD2[2,3] = 5
	SRD3 = rate.mat.maker(rate.cat=1, hrm=FALSE, ntraits=1, nstates=3, model="ARD")
	SRD3[1,2] = 1
	SRD3[3,2] = 2
	SRD3[1,3] = 2
	SRD3[2,3] = 2
	SRD4 = rate.mat.maker(rate.cat=1, hrm=FALSE, ntraits=1, nstates=3, model="ARD")
	SRD4 = rate.par.drop(SRD4, drop.par = c(1,3))
	SRD4[3,2] = 1
	SRD4[2,3] = 3
	
	#Run simulation
	SRD1Mul = rayDISC(phy=tree, data=multiState, rate.mat = SRD1, node.states = "marginal", root.p = "maddfitz")
	SRD2Mul = rayDISC(phy=tree, data=multiState, rate.mat = SRD2, node.states = "marginal", root.p = "maddfitz")
	SRD3Mul = rayDISC(phy=tree, data=multiState, rate.mat = SRD3, node.states = "marginal", root.p = "maddfitz")
	SRD4Mul = rayDISC(phy=tree, data=multiState, rate.mat = SRD4, node.states = "marginal", root.p = "maddfitz")

#Binary
	#Run simulation
	ERBin = rayDISC(phy = tree, data = binary, model = "ER", node.states = "marginal", root.p = "maddfitz")
	ARDBin = rayDISC(phy = tree, data = binary, model = "ARD", node.states = "marginal", root.p = "maddfitz")
	
#Create dummy simmap to plot results
binary_data = setNames(parsed_data$V3, parsed_data$V1)
multistate_data = setNames(parsed_data$V2, parsed_data$V1)
simmap_binary = make.simmap(tree = tree, x = binary_data, model = "ER", nsim = 10, pi = "equal")
simmap_multistate = make.simmap(tree = tree, x = multistate_data, model = "ER", nsim = 10, pi = "equal")
summary_binary = summary(simmap_binary)
summary_multistate = summary(simmap_multistate)

#Colors for plots
Cols2 <- c('0'="orange", '1'="blue")
Cols3 <- c('0'="orange", '1'="blue", '2'="red")
	
#Plot unordered ER multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = unordERMul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf unordERMulCorHMM.pdf")

#Plot unordered ARD multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = unordARDMul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf unordARDMulCorHMM.pdf")

#Plot unordered SYM multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = unordSYMMul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf unordSYMMulCorHMM.pdf")

#Plot ordered ER multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = ordERMul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf ordERMulCorHMM.pdf")

#Plot ordered ARD multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = ordARDMul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf ordARDMulCorHMM.pdf")

#Plot ordered SYM multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = ordSYMMul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf ordSYMMulCorHMM.pdf")

#Plot ordered SRD1 multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = SRD1Mul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf SRD1MulCorHMM.pdf")

#Plot ordered SRD2 multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = SRD2Mul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf SRD2MulCorHMM.pdf")

#Plot ordered SRD3 multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = SRD3Mul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf SRD3MulCorHMM.pdf")

#Plot ordered SRD4 multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = SRD4Mul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf SRD4MulCorHMM.pdf")

#Plot ER binary
for (i in seq(1, 118))
{
	summary_binary$ace[i,] = ERBin$states[i,]
}
plot(summary_binary, fsize=.4, colors=Cols2, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine"), colors = Cols2, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf ERBinCorHMM.pdf")

#Plot ARD binary
for (i in seq(1, 118))
{
	summary_binary$ace[i,] = ARDBin$states[i,]
}
plot(summary_binary, fsize=.4, colors=Cols2, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine"), colors = Cols2, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf ARDBinCorHMM.pdf")
	
cat("1. Unordered ER Multistate\n")
print(unordERMul)
cat("Probs:\n")
print(unordERMul$states[1,])
print(unordERMul$states[6,])
print(unordERMul$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("2. Unordered ARD Multistate\n")
print(unordARDMul)
cat("Probs:\n")
print(unordARDMul$states[1,])
print(unordARDMul$states[6,])
print(unordARDMul$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("3. Unordered SYM Multistate\n")
print(unordSYMMul)
cat("Probs:\n")
print(unordSYMMul$states[1,])
print(unordSYMMul$states[6,])
print(unordSYMMul$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("3. Ordered ER Multistate\n")
print(ordERMul)
cat("Probs:\n")
print(ordERMul$states[1,])
print(ordERMul$states[6,])
print(ordERMul$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("4. Ordered ARD Multistate\n")
print(ordARDMul)
cat("Probs:\n")
print(ordARDMul$states[1,])
print(ordARDMul$states[6,])
print(ordARDMul$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("5. Ordered SYM Multistate\n")
print(ordSYMMul)
cat("Probs:\n")
print(ordSYMMul$states[1,])
print(ordSYMMul$states[6,])
print(ordSYMMul$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("6. SRD1 Multistate\n")
print(SRD1Mul)
cat("Probs:\n")
print(SRD1Mul$states[1,])
print(SRD1Mul$states[6,])
print(SRD1Mul$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("7. SRD2 Multistate\n")
print(SRD2Mul)
cat("Probs:\n")
print(SRD2Mul$states[1,])
print(SRD2Mul$states[6,])
print(SRD2Mul$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("8. SRD3 Multistate\n")
print(SRD3Mul)
cat("Probs:\n")
print(SRD3Mul$states[1,])
print(SRD3Mul$states[6,])
print(SRD3Mul$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("9. SRD4 Multistate\n")
print(SRD4Mul)
cat("Probs:\n")
print(SRD4Mul$states[1,])
print(SRD4Mul$states[6,])
print(SRD4Mul$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("10. ER Binary\n")
print(ERBin)
cat("Probs:\n")
print(ERBin$states[1,])
print(ERBin$states[6,])
print(ERBin$states[7,])

readline("Press enter to continue")
cat("\n\n\n\n\n\n\n")

cat("11. ARD Binary\n")
print(ARDBin)
cat("Probs:\n")
print(ARDBin$states[1,])
print(ARDBin$states[6,])
print(ARDBin$states[7,])
