commandLineArgs = commandArgs(trailingOnly = TRUE)

if (length(commandLineArgs) != 3)
{
	cat("\n\tWrong parameters.\n\n\tRequired parameters:\n\n\t\t\tTree file\tData file\t\tSeed\n\n")
	quit(save = "no", status = 64, runLast = FALSE)
}

#Parse command line arguments
sptreeFile = commandLineArgs[1]
dataFile = commandLineArgs[2]
seed = commandLineArgs[3]

library(corHMM)
library(phytools)

set.seed(seed)

#Read the species tree file
tree = read.tree(sptreeFile)
tree$tip.label = tolower(tree$tip.label)
tree = ladderize(tree, right=FALSE)

#Read character state data
parsed_data = read.table(dataFile, header=FALSE, sep="\t")

#Create data frames
multiState = data.frame(Names=parsed_data$V1, Habitat=parsed_data$V2, stringsAsFactors=FALSE)
binary = data.frame(Names=parsed_data$V1, Habitat=parsed_data$V3, stringsAsFactors=FALSE)

#Multistate
	#Define transition matrices
	pSAICcMul = c(0.127010524, 13.09384136, 0.111076133, 11.88493471, 0.285844675, 0.781592714)
	pBMAMul = c(0.092423306, 19.48437895, 0.092115087, 19.61011998, 0.690525173, 0.795255126)
	#Run simulation
	SAICcMul = rayDISC(phy = tree, data = multiState, model="ARD", node.states = "marginal", root.p = "maddfitz", p = pSAICcMul)
	BMAMul = rayDISC(phy = tree, data = multiState, model="ARD", node.states = "marginal", root.p = "maddfitz", p = pBMAMul)
	
#Binary
	#Define transition matrices
	pSAICcBin = c(0.552237755, 0.224519624)
	pBMABin = c(0.519629864, 0.315994456)
	
	#Run simulation
	SAICcBin = rayDISC(phy = tree, data = binary, model="ARD", node.states = "marginal", root.p = "maddfitz", p = pSAICcBin)
	BMABin = rayDISC(phy = tree, data = binary, model="ARD", node.states = "marginal", root.p = "maddfitz", p = pBMABin)
	
#Create dummy simmap to plot results
binary_data = setNames(parsed_data$V3, parsed_data$V1)
multistate_data = setNames(parsed_data$V2, parsed_data$V1)
simmap_binary = make.simmap(tree = tree, x = binary_data, model = "ER", nsim = 10, pi = "equal")
simmap_multistate = make.simmap(tree = tree, x = multistate_data, model = "ER", nsim = 10, pi = "equal")
summary_binary = summary(simmap_binary)
summary_multistate = summary(simmap_multistate)

#Colors for plots
Cols2 <- c('0'="orange", '1'="blue")
Cols3 <- c('0'="orange", '1'="blue", '2'="red")
	
#Plot SAICc multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = SAICcMul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf SAICcMulCorHMM.pdf")

#Plot BMA multistate
for (i in seq(1, 118))
{
	summary_multistate$ace[i,] = BMAMul$states[i,]
}
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf BMAMulCorHMM.pdf")

#Plot SAICc binary
for (i in seq(1, 118))
{
	summary_binary$ace[i,] = SAICcBin$states[i,]
}
plot(summary_binary, fsize=.4, colors=Cols2, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine"), colors = Cols2, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf SAICcBinCorHMM.pdf")

#Plot BMA binary
for (i in seq(1, 118))
{
	summary_binary$ace[i,] = BMABin$states[i,]
}
plot(summary_binary, fsize=.4, colors=Cols2, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine"), colors = Cols2, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf BMABinCorHMM.pdf")
	
cat("1. SAICc Multistate\n")
print(SAICcMul)
cat("Probs:\n")
print(SAICcMul$states[1,])
print(SAICcMul$states[6,])
print(SAICcMul$states[7,])

cat("\n\n\n\n\n\n\n")

cat("2. BMA Multistate\n")
print(BMAMul)
cat("Probs:\n")
print(BMAMul$states[1,])
print(BMAMul$states[6,])
print(BMAMul$states[7,])

cat("\n\n\n\n\n\n\n")

cat("3. SAICc Binary\n")
print(SAICcBin)
cat("Probs:\n")
print(SAICcBin$states[1,])
print(SAICcBin$states[6,])
print(SAICcBin$states[7,])

cat("\n\n\n\n\n\n\n")

cat("4. BMA Binary\n")
print(BMABin)
cat("Probs:\n")
print(BMABin$states[1,])
print(BMABin$states[6,])
print(BMABin$states[7,])
