 commandLineArgs = commandArgs(trailingOnly = TRUE)

if (length(commandLineArgs) != 3)
{
	cat("\n\tWrong parameters.\n\n\tRequired parameters:\n\n\t\t\tTree file\tData file\tSeed\n\n")
	quit(save = "no", status = 64, runLast = FALSE)
}

#Parse command line arguments
sptreeFile = commandLineArgs[1]
dataFile = commandLineArgs[2]
seed = commandLineArgs[3]

library(phytools)

#By default make.simmap does not report log-likelihoods, although they are computed
source("make.simmap.R")

#Read the species tree file
tree = read.tree(sptreeFile)
tree = ladderize(tree, right=FALSE)
tree$tip.label = tolower(tree$tip.label)

#Read character state data
parsed_data = read.table(dataFile, header=FALSE, sep="\t")

#Create named vector
binary_data = setNames(parsed_data$V3, parsed_data$V1)

#Set random number seed (for reproducibility)
set.seed(seed)

#Create rate matrix
Q = matrix(c(-0.276982571, 0.276982571, 0.555685847, -0.555685847), nrow=2, ncol=2, byrow=TRUE)
rownames(Q) = c(0, 1)
colnames(Q) = c(0, 1)

#Make simmaps
simmap_binary = make.simmap_withAttr(tree = tree, x = binary_data, Q = Q, nsim = 1000, pi = "equal")

#Summarize data
summary_binary = summary(simmap_binary)

#Colors for plots
Cols2 <- c('0'="orange", '1'="blue")

#Plot binary
plot(summary_binary, fsize=.4, colors=Cols2, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine"), colors = Cols2, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf binarySAICc.pdf")

cat("Binary SAICc\n")
cat("Rates:\n")
attr(simmap_binary, "Q")
cat("lnL:\n")
attr(simmap_binary, "logL")
cat("Probs:\n")
print(summary_binary$ace[1,])
print(summary_binary$ace[6,])
print(summary_binary$ace[7,])
