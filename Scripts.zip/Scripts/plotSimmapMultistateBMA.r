 commandLineArgs = commandArgs(trailingOnly = TRUE)

if (length(commandLineArgs) != 3)
{
	cat("\n\tWrong parameters.\n\n\tRequired parameters:\n\n\t\t\tTree file\tData file\tSeed\n\n")
	quit(save = "no", status = 64, runLast = FALSE)
}

#Parse command line arguments
sptreeFile = commandLineArgs[1]
dataFile = commandLineArgs[2]
seed = commandLineArgs[3]

library(phytools)

#By default make.simmap does not report log-likelihoods, although they are computed
source("make.simmap.R")

#Read the species tree file
tree = read.tree(sptreeFile)
tree = ladderize(tree, right=FALSE)
tree$tip.label = tolower(tree$tip.label)

#Read character state data
parsed_data = read.table(dataFile, header=FALSE, sep="\t")

#Create named vector
multistate_data = setNames(parsed_data$V2, parsed_data$V1)

#Set random number seed (for reproducibility)
set.seed(seed)

#Create rate matrix
Q = matrix(c(-0.444666611, 0.444666611, 0, 0.466435038, -0.542884492, 0.076449454, 0.224426877, 0.328068542, -0.552495419), nrow=3, ncol=3, byrow=TRUE)

rownames(Q) = c(0, 1, 2)
colnames(Q) = c(0, 1, 2)

#Make simmaps
simmap_multistate = make.simmap_withAttr(tree = tree, x = multistate_data, Q = Q, nsim = 1000, pi = "equal")

#Summarize data
summary_multistate = summary(simmap_multistate)

#Colors for plots
Cols3 <- c('0'="orange", '1'="blue", '2'="red")

#Plot multistate
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system("mv Rplots.pdf multistateBMA.pdf")

cat("Multistate BMA\n")
cat("Rates:\n")
attr(simmap_multistate, "Q")
cat("lnL:\n")
attr(simmap_multistate, "logL")
cat("Probs:\n")
print(summary_multistate$ace[1,])
print(summary_multistate$ace[6,])
print(summary_multistate$ace[7,])
