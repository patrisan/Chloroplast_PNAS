commandLineArgs = commandArgs(trailingOnly = TRUE)

if (length(commandLineArgs) != 6)
{
	cat("\n\tWrong parameters.\n\n\tRequired parameters:\n\n\t\t\tTree file\tData file\tModel (ER, ARD, SYM)\t\tSeed\tAlpha\tBeta\n\n")
	quit(save = "no", status = 64, runLast = FALSE)
}

#Parse command line arguments
sptreeFile = commandLineArgs[1]
dataFile = commandLineArgs[2]
specifiedModel = commandLineArgs[3]
seed = commandLineArgs[4]

prior = list()
prior$alpha = as.numeric(commandLineArgs[5])
prior$beta = as.numeric(commandLineArgs[6])

library(phytools)

#By default make.simmap does not report log-likelihoods, although they are computed
source("make.simmap.R")

#Read the species tree file
tree = read.tree(sptreeFile)
tree = ladderize(tree, right=FALSE)
tree$tip.label = tolower(tree$tip.label)

#Read character state data
parsed_data = read.table(dataFile, header=FALSE, sep="\t")

#Create named vectors
binary_data = setNames(parsed_data$V3, parsed_data$V1)
multistate_data = setNames(parsed_data$V2, parsed_data$V1)

#Set random number seed (for reproducibility)
set.seed(seed)

#Make simmaps
simmap_binary = make.simmap_withAttr(tree = tree, x = binary_data, model = specifiedModel, nsim = 1000, pi = "equal", Q = "mcmc", prior = prior)
simmap_multistate = make.simmap_withAttr(tree = tree, x = multistate_data, model = specifiedModel, nsim = 1000, pi = "equal", Q = "mcmc", prior = prior)

#Summarize data
summary_binary = summary(simmap_binary)
summary_multistate = summary(simmap_multistate)

#Colors for plots
Cols2 <- c('0'="orange", '1'="blue")
Cols3 <- c('0'="orange", '1'="blue", '2'="red")

#Plot binary
plot(summary_binary, fsize=.4, colors=Cols2, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine"), colors = Cols2, prompt = FALSE, x=0, y=115)
graphics.off()
system(paste("mv Rplots.pdf binary", specifiedModel, "_", prior$alpha, "_", prior$beta, ".pdf", sep=""))

#Plot multistate
plot(summary_multistate, fsize=.4, colors=Cols3, lwd=.9, ftype="reg", cex=.3)
nodelabels(node = c(120, 125, 126), adj=c(1.1,-1), bg="white", text = c("R", "G+A", "A"))
add.simmap.legend(leg = c("Freshwater", "Marine", "Brackish"), colors = Cols3, prompt = FALSE, x=0, y=115)
graphics.off()
system(paste("mv Rplots.pdf multistate", specifiedModel, "_", prior$alpha, "_", prior$beta, ".pdf", sep=""))

cat("Binary\n")
cat("Probs:\n")
print(summary_binary$ace[1,])
print(summary_binary$ace[6,])
print(summary_binary$ace[7,])
cat("\n\n")
cat("Multistate\n")
cat("Probs:\n")
print(summary_multistate$ace[1,])
print(summary_multistate$ace[6,])
print(summary_multistate$ace[7,])
