commandLineArgs = commandArgs(trailingOnly = TRUE)

if (length(commandLineArgs) != 6)
{
	cat("\n\tWrong parameters.\n\n\tRequired parameters:\n\n\t\t\tTree file\tData file\tModel (ER, ARD)\t\tSeed\tAlpha\tBeta\n\n")
	quit(save = "no", status = 64, runLast = FALSE)
}

#Parse command line arguments
sptreeFile = commandLineArgs[1]
dataFile = commandLineArgs[2]
specifiedModel = commandLineArgs[3]
seed = commandLineArgs[4]

prior = list()
prior$alpha = as.numeric(commandLineArgs[5])
prior$beta = as.numeric(commandLineArgs[6])

library(phytools)
library(methods)

#Read the species tree file
tree = read.tree(sptreeFile)
tree = ladderize(tree, right=FALSE)
tree$tip.label = tolower(tree$tip.label)

#Read character state data
parsed_data = read.table(dataFile, header=FALSE, sep="\t")

#Create named vectors
multistate_data = setNames(parsed_data$V2, parsed_data$V1)

#Set random number seed (for reproducibility)
set.seed(seed)
cat(paste("Seed: ", seed, "\n", sep=""))

#Read the files containing the species that are to be shuffled
bluesp = tolower(readLines("BlueSpecies.txt"))
greensp = tolower(readLines("GreenSpecies.txt"))

#Remove the trees file, if it exists
system("rm -f trees")

#Shuffle the blue and green species
for (j in seq(1, 100))
{
	nbluesp = sample(bluesp, length(bluesp))
	ngreensp = sample(greensp, length(greensp))
	
	blueNames = setNames(nbluesp, bluesp)
	greenNames = setNames(ngreensp, greensp)
	
	ctree = tree
	
	for (i in seq(1, length(ctree$tip.label)))
	{
		if (ctree$tip.label[i] %in% bluesp)
		{
			ctree$tip.label[i] = blueNames[ctree$tip.label[i]]
		} else
		{
			if (ctree$tip.label[i] %in% greensp)
			{
				ctree$tip.label[i] = greenNames[ctree$tip.label[i]]
			}
		}
	}
	write.tree(ctree, file="trees", append=TRUE)
}

#Read the shuffled trees in a multiPhylo object
trees = read.tree("trees")

#Make simmaps
simmap_multistate = make.simmap(tree = trees, x = multistate_data, model = specifiedModel, nsim = 1, pi = "equal", Q = "mcmc", prior = prior)

#Save simmaps to disk
write.simmap(simmap_multistate, "multistate.maps")
